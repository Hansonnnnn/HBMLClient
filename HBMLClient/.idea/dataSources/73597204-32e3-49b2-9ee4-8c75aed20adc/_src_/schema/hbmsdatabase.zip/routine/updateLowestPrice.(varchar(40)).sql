CREATE PROCEDURE `updateLowestPrice`(`difference` VARCHAR(40))
  BEGIN
	set @temp = concat("update hotel inner join (select min(",difference,") curPrice,hotelID from roomprice inner join roominfo on roomprice.roomInfoID = roominfo.roomInfoID group by hotelID) temp on hotel.hotelID=temp.hotelID set hotel.lowestPrice = temp.curPrice ");
	prepare stmt from @temp;
    execute stmt;
    deallocate prepare stmt;
	
   
END