CREATE PROCEDURE `updateOrderState`()
  BEGIN
	
    update orderlist set orderState = 2 where now()>=executeDDL and orderState =0;
END