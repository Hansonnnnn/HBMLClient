CREATE PROCEDURE `testCall`(`difference` VARCHAR(40))
  BEGIN
	set @temp = concat("select min(",difference,") curPrice,hotelID from roomprice inner join roominfo on roomprice.roomInfoID = roominfo.roomInfoID group by hotelID");
	prepare stmt from @temp;
    execute stmt;
    deallocate prepare stmt;
END