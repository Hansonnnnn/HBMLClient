CREATE PROCEDURE `setRank`(`user_ID` INT(11), `creditValue` INT(11))
  BEGIN
	set rank=0;
    if creditValue>=500 and creditValue<1500 then
		set rank=1;
	elseif creditValue>=1500 and creditValue<3000 then
		set rank=2;
	elseif creditValue>=3000 and creditValue<6000 then
		set rank=3;
	elseif creditValue>=6000 and creditValue<10000 then
		set rank=4;
	elseif creditValue>=10000 and creditValue<25000 then
		set rank=5;
	elseif creditValue>=25000 and creditValue<50000 then
		set rank=6;
	elseif creditValue>=50000 then
		set rank=7;

	end if;

END