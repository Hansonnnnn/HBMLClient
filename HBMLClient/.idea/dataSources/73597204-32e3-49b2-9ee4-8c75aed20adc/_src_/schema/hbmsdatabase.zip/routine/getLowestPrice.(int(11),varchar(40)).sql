CREATE PROCEDURE `getLowestPrice`(`hotelID` INT(11), `difference` VARCHAR(40))
  BEGIN
	
	SET @v_sql=CONCAT('select min(', difference,') from (select roomInfoID from roominfo where roominfo.hotelID = ',hotelID,') temp inner join roomprice on temp.roomInfoID = roomprice.roomInfoID');
    
    prepare test from @v_sql;

    execute test;
END