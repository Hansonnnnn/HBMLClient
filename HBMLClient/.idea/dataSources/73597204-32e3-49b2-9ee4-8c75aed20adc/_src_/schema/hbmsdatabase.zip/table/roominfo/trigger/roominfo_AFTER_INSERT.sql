CREATE TRIGGER `roominfo_AFTER_INSERT`
AFTER INSERT ON `roominfo`
FOR EACH ROW
  BEGIN
   insert into roomdate(roomInfoID,curDay) values(new.roomInfoID,now());
   insert into roomprice(roomInfoID,curDay,defaultPrice) values(new.roomInfoID,now(),new.defaultPrice);
END