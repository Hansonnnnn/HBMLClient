CREATE TRIGGER `roominfo_AFTER_UPDATE`
AFTER UPDATE ON `roominfo`
FOR EACH ROW
  BEGIN
    if old.defaultPrice!=new.defaultPrice then
    update roomprice set roomprice.defaultPrice = new.defaultPrice where roomprice.roomInfoID = new.roomInfoID;
    end if;
    
    if old.roomState!=new.roomState then
        if new.roomState =0 then
        update roomdate 
        set day00=0,
        day01=0,
        day02=0,
        day03=0,
        day04=0,
        day05=0,
        day06=0,
        day07=0,
        day08=0,
        day09=0,
        day10=0,
        day11=0,
        day12=0,
        day13=0,
        day14=0,
        day15=0,
        day16=0,
        day17=0,
        day18=0,
        day19=0,
        day20=0,
        day21=0,
        day22=0,
        day23=0,
        day24=0,
        day25=0,
        day26=0,
        day27=0,
        day28=0,
        day29=0,
        day30=0
        where roomdate.roomInfoID = new.roomInfoID;
        else 
            if old.roomState=0 then
            update roomdate 
            set day00=1,
            day01=1,
            day02=1,
            day03=1,
            day04=1,
            day05=1,
            day06=1,
            day07=1,
            day08=1,
            day09=1,
            day10=1,
            day11=1,
            day12=1,
            day13=1,
            day14=1,
            day15=1,
            day16=1,
            day17=1,
            day18=1,
            day19=1,
            day20=1,
            day21=1,
            day22=1,
            day23=1,
            day24=1,
            day25=1,
            day26=1,
            day27=1,
            day28=1,
            day29=1,
            day30=1   
            where roomdate.roomInfoID = new.roomInfoID;
            end if;
        end if;
    end if;
END