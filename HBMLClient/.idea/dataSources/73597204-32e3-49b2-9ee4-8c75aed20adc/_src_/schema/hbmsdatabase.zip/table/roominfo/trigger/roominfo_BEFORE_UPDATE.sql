CREATE TRIGGER `roominfo_BEFORE_UPDATE`
BEFORE UPDATE ON `roominfo`
FOR EACH ROW
  BEGIN
    if new.roomState=1 and old.roomState=3 then
       -- update orderlist set checkoutTime = now() where orderlist.roomInfoID = new.roomInfoID and executeDDL=DATE_ADD(CURDATE(), INTERVAL -6 HOUR);
        if (select day00 from roomdate where roomdate.roomInfoID=new.roomInfoID)=0 then
        set new.roomState=2, new.detailedInfo1=DATE_ADD(CURDATE(), INTERVAL +12 HOUR),new.detailedInfo2=null;
        else set new.detailedInfo1=null,new.detailedInfo2 = now();
        end if;
    
    
    else if new.roomState=1 and old.roomState!=new.roomState then
        set new.detailedInfo1=null,new.detailedInfo2=null;
    end if;
    end if;
END