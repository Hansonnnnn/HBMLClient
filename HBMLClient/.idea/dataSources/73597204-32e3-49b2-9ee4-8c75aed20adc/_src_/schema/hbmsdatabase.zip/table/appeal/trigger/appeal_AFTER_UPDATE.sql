CREATE TRIGGER `appeal_AFTER_UPDATE`
AFTER UPDATE ON `appeal`
FOR EACH ROW
  BEGIN
    if new.appealState=1 and old.appealState!=1 then
     update orderlist set orderState = 3 where orderlist.orderID = new.orderID;
    end if;
END