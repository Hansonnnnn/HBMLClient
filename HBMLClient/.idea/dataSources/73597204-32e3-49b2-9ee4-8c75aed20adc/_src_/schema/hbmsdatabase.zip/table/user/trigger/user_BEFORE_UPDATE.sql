CREATE TRIGGER `user_BEFORE_UPDATE`
BEFORE UPDATE ON `user`
FOR EACH ROW
  BEGIN
    if new.creditValue!=old.creditValue then
        call setRank(new.userID,new.creditValue,@rank);
        set new.rank = @rank;
    end if;
END