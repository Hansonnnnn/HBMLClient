CREATE TRIGGER `roomprice_AFTER_UPDATE`
BEFORE UPDATE ON `roomprice`
FOR EACH ROW
  BEGIN
    if old.defaultPrice!= new.defaultPrice  then 
    set new.day00=new.defaultPrice,
    new.day01=new.defaultPrice,
    new.day02=new.defaultPrice,
    new.day03=new.defaultPrice,
    new.day04=new.defaultPrice,
    new.day05=new.defaultPrice,
    new.day06=new.defaultPrice,
    new.day07=new.defaultPrice,
    new.day08=new.defaultPrice,
    new.day09=new.defaultPrice,
    new.day10=new.defaultPrice,
    new.day11=new.defaultPrice,
    new.day12=new.defaultPrice,
    new.day13=new.defaultPrice,
    new.day14=new.defaultPrice,
    new.day15=new.defaultPrice,
    new.day16=new.defaultPrice,
    new.day17=new.defaultPrice,
    new.day18=new.defaultPrice,
    new.day19=new.defaultPrice,
    new.day20=new.defaultPrice,
    new.day21=new.defaultPrice,
    new.day22=new.defaultPrice,
    new.day23=new.defaultPrice,
    new.day24=new.defaultPrice,
    new.day25=new.defaultPrice,
    new.day26=new.defaultPrice,
    new.day27=new.defaultPrice,
    new.day28=new.defaultPrice,
    new.day29=new.defaultPrice,
    new.day30=new.defaultPrice ;
    end if;
END