CREATE TRIGGER `orderlist_AFTER_UPDATE`
AFTER UPDATE ON `orderlist`
FOR EACH ROW
  BEGIN
    if (new.orderState =1 and old.orderState!=1) then
    update roominfo set roomState =3,detailedInfo1 = new.checkinTime,detailedInfo2 =DATE_ADD(CURDATE(), INTERVAL +36 HOUR) where roominfo.roomInfoID=new.roomInfoID;
        if old.orderState=0 then
            update user set creditValue = creditValue+new.price where user.userID = new.userID;
            insert into creditrecord(userID,reasonType,amount,orderID) values(new.userID,0,new.price,new.orderID);
        end if;
        if old.orderState=2 then
            update user set creditValue = creditValue+new.price where user.userID = new.userID;
            insert into creditrecord(userID,reasonType,amount,orderID) values(new.userID,3,new.price,new.orderID);
            update user set creditValue = creditValue+new.price where user.userID = new.userID;
            insert into creditrecord(userID,reasonType,amount,orderID) values(new.userID,0,new.price,new.orderID);
        end if;
    else
        if new.checkoutTIme is not null and old.checkoutTime is null then
        update roominfo set roomState =1 where roominfo.roomInfoID=new.roomInfoID;
        end if;
    end if;
    if(new.orderState=2 and old.orderState!=2) then
        update user set creditValue = creditValue-new.price where user.userID = new.userID;
        insert into creditrecord(userID,reasonType,amount,orderID) values(new.userID,2,-new.price,new.orderID);
    end if;
    if(new.orderState=3 and old.orderState!=3) then
        if timestampdiff(hour,new.cancelTime,new.executeDDL)<6 then
            update user set creditValue = creditValue-new.price/2 where user.userID = new.userID;
            insert into creditrecord(userID,reasonType,amount,orderID) values(new.userID,1,-new.price/2,new.orderID);
        end if;
    end if;
    
END