CREATE TRIGGER `commentinfo_AFTER_INSERT`
AFTER INSERT ON `commentinfo`
FOR EACH ROW
  BEGIN
    update hotel set score = (select format(avg(score),2) from commentinfo where hotelID = new.hotelID) where hotel.hotelID = new.hotelID;
END